# Garage System: Final Project

## Advanced developer lab 2020

### User Manual
1. Run the exe file.
2. Login into the system with username and password.
3. Follow the menu instructions.

### Copyrights
- Barak Pahima
- Raviv Nachum

### Example

![Example](example.png)
